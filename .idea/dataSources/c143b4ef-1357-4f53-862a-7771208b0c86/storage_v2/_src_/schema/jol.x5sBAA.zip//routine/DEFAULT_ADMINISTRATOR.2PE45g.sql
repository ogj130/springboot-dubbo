create procedure DEFAULT_ADMINISTRATOR(IN user_name varchar(48))
BEGIN
    DECLARE privileged_count INT DEFAULT 0;
    SET privileged_count=(SELECT COUNT(1) FROM `privilege`);
    IF privileged_count=0 THEN
        INSERT INTO `privilege` values(user_name,'administrator','N');
    end if;
end;

